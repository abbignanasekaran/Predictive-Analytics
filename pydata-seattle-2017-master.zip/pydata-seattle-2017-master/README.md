# pydata-seattle-2017
Materials for DataScience.com LTV and Neural Nets Talks at PyData Seattle
